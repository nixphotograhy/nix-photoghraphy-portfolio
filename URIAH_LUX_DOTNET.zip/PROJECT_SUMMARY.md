# Project Heritage: Uriah Lux Atelier

This document serves as the "Master Memory" for the Uriah Lux Shopify theme transformation. It captures the architectural decisions, aesthetic DNA, and functional features implemented to create a high-fidelity luxury storefront.

## 🏛️ Project DNA
- **Brand Identity**: Uriah Lux — Minimalist, Editorial, High-Fashion Fragrance & Lifestyle.
- **Design Philosophy**: Glassmorphism, Bento-grid layouts, and "Tactile Ethereal" layering.
- **Master Palette**: 
    - **Base**: Champagne Silk (`#F7F3E9`)
    - **Accent**: Atelier Olive (`#5D673B`)
    - **Contrast**: Onyx Black (`#1A1A1A`)
- **Typography**: 
    - **Headlines**: Newsreader Serif (Weight 800)
    - **UI/Body**: Manrope Sans-Serif (Weight 400-700)

## 🚀 Key Features Implemented

### 1. **Atelier Core Layout**
- **Glassmorphism Header**: Fixed-position with 70% transparency and 32px Gaussian blur. Custom bespoke SVG icons for Cart and Profile.
- **Infinite Sale Marquee**: A high-speed, infinite scrolling announcement banner (Olive Background) bridge between header and content.
- **Champagne Foundation**: Global background set to Silk-finish cream, replacing generic white.

### 2. **Conversion-Engine (Product Experience)**
- **Dynamic Hero**: Precision-linked to the 'Star Product' via section settings. Full image-pedestal is clickable for frictionless conversion.
- **Advanced Product Page**:
    - **Dual-Action Checkout**: "Add to Cart" + Shopify "Buy It Now" accelerated buttons.
    - **Scarcity Pulse**: Live inventory counter ("Rare Batch: Only X pieces remaining").
    - **Scent Spectrum**: Visual 1-10 intensity indicator for projection power.
    - **Benefit Stack**: Premium "Clay" pills for Vegan, 24h Wear, and Ethical Sourcing.
    - **Sticky Storytelling**: Sticky image gallery on the left with a scrollable information column on the right.

### 3. **The 'Cart Concierge'**
- **AJAX Drawer**: A full slide-out slide panel that allows customers to add items and manage their cart without leaving the page.
- **Spring Physics**: Implemented smooth Cubic-Bezier transitions for the drawer opening/closing.

### 4. **Editorial Catalog & Browse**
- **Atelier Grid**: 48px rounded product cards with cycling neutral backgrounds (#EEEDE8, etc.).
- **Typography Parity**: Guaranteed that product titles and prices match exactly across Homepage, Bestsellers, and Catalog.
- **Bento Contact**: A redesigned Contact Us section using the Bento-grid aesthetic and premium "Clay" input fields.

## 📁 Technical Map (Key Files)
- `layout/theme.liquid`: Main structural logic, Font imports, and AJAX ATC interceptors.
- `assets/base.css`: Global design system, colors, typography, and animation keyframes.
- `sections/cart-drawer.liquid`: Custom section for the slide-out cart.
- `sections/main-product.liquid`: The "Convert" engine with scarcity and intensity features.
- `sections/hero.liquid`: High-fidelity landing section with dynamic product linking.
- `sections/marquee.liquid`: The promotional scroll engine.

## 🧪 Verification Status
- [x] All navigation links repaired (no dead '#' links).
- [x] Cart Drawer functional on both Product and Header triggers.
- [x] Mobile responsiveness optimized for Bento grids and Product layout.
