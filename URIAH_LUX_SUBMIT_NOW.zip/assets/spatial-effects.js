/**
 * Spatial UI Animations
 * Using Native Web Animations API for "Tactile" physics.
 * No external libraries (GSAP/Three) as per performance protocol.
 */

document.addEventListener('DOMContentLoaded', () => {
  const tactileElements = document.querySelectorAll('.button-tactile, .bento-item, .hero-visual');

  tactileElements.forEach(el => {
    // Tactile "Squish" on Click
    el.addEventListener('mousedown', () => {
      el.animate([
        { transform: 'scale(1)', boxShadow: 'var(--z-depth-mid-shadow)' },
        { transform: 'scale(0.95)', boxShadow: 'var(--z-depth-low-shadow)' }
      ], {
        duration: 150,
        easing: 'cubic-bezier(0.34, 1.56, 0.64, 1)',
        fill: 'forwards'
      });
    });

    el.addEventListener('mouseup', () => {
      el.animate([
        { transform: 'scale(0.95)', boxShadow: 'var(--z-depth-low-shadow)' },
        { transform: 'scale(1.02)', boxShadow: 'var(--z-depth-high-shadow)' },
        { transform: 'scale(1)', boxShadow: 'var(--z-depth-mid-shadow)' }
      ], {
        duration: 300,
        easing: 'cubic-bezier(0.34, 1.56, 0.64, 1)',
        fill: 'forwards'
      });
    });

    // Spatial Hover Parallax (Subtle)
    el.addEventListener('mousemove', (e) => {
      if (!el.classList.contains('hero-visual')) return;
      
      const rect = el.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      
      const centerX = rect.width / 2;
      const centerY = rect.height / 2;
      
      const rotateX = (y - centerY) / 20;
      const rotateY = (centerX - x) / 20;

      el.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale(1.02)`;
    });

    el.addEventListener('mouseleave', () => {
      el.style.transform = '';
    });
  });
});
