/**
 * Liquid Glass Houdini Paint Worklet
 * Generates a dynamic, high-performance frost texture.
 */

class LiquidGlassPainter {
  static get inputProperties() { return ['--glass-opacity', '--glass-blur']; }
  
  paint(ctx, geom, properties) {
    const opacity = parseFloat(properties.get('--glass-opacity').toString()) || 0.1;
    
    // Create subtle grain/frost
    for (let x = 0; x < geom.width; x += 4) {
      for (let y = 0; y < geom.height; y += 4) {
        const alpha = Math.random() * opacity;
        ctx.fillStyle = `rgba(255, 255, 255, ${alpha})`;
        ctx.fillRect(x, y, 2, 2);
      }
    }
  }
}

registerPaint('liquid-glass', LiquidGlassPainter);
