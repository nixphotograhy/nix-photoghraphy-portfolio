/**
 * Premium Scroll Reveal & Parallax
 * Intersection Observer-based for performance
 */
document.addEventListener('DOMContentLoaded', () => {
  // Header scroll effect
  const header = document.querySelector('.header-main');
  if (header) {
    window.addEventListener('scroll', () => {
      if (window.scrollY > 20) {
        header.classList.add('is-glassy');
      } else {
        header.classList.remove('is-glassy');
      }
    }, { passive: true });
  }

  // Scroll Reveal
  const revealEls = document.querySelectorAll('.reveal, .reveal-left, .reveal-right, .reveal-scale, .reveal-stagger');
  
  if (revealEls.length > 0) {
    const revealObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          revealObserver.unobserve(entry.target);
        }
      });
    }, {
      threshold: 0.15,
      rootMargin: '0px 0px -60px 0px'
    });

    revealEls.forEach(el => revealObserver.observe(el));
  }

  // Smooth parallax on hero image
  const heroShowcase = document.querySelector('.hero-showcase-bg');
  if (heroShowcase) {
    window.addEventListener('scroll', () => {
      const scrollTop = window.pageYOffset;
      const rate = scrollTop * 0.15;
      heroShowcase.style.transform = `translateY(${rate}px)`;
    }, { passive: true });
  }

  // Product image gallery
  const thumbs = document.querySelectorAll('.product-thumb');
  const mainImg = document.getElementById('ProductMainImage');
  
  if (thumbs.length && mainImg) {
    thumbs.forEach(thumb => {
      thumb.addEventListener('click', () => {
        const newSrc = thumb.dataset.src;
        mainImg.src = newSrc;
        thumbs.forEach(t => t.classList.remove('active'));
        thumb.classList.add('active');
      });
    });
  }
});
